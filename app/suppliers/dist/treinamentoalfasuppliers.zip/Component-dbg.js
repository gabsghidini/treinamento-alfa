sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("treinamento.alfa.suppliers.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);